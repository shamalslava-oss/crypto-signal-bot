import time
import requests
from telegram import Bot

BYBIT_API_KEY = "YOUR_KEY"
BYBIT_SECRET = "YOUR_SECRET"

TELEGRAM_TOKEN = "YOUR_TELEGRAM_TOKEN"
CHAT_ID = "YOUR_CHAT_ID"

bot = Bot(token=TELEGRAM_TOKEN)


def get_spot_symbols():
    url = "https://api.bybit.com/v5/market/tickers?category=spot"
    data = requests.get(url).json()
    return data["result"]["list"]


def check_signal():
    symbols = get_spot_symbols()
    signals = []

    for s in symbols:
        try:
            price_change = float(s["price24hPcnt"]) * 100
            volume = float(s["volume24h"])

            if price_change > 1 and volume > 100000:
                signals.append(
                    f"🚀 Сигнал\n"
                    f"Монета: {s['symbol']}\n"
                    f"Рост 24ч: {price_change:.2f}%\n"
                    f"Объём 24ч: {volume:,.0f}\n"
                    f"Стоп: -1%\n"
                    f"Тейк: +2%"
                )
        except:
            continue

    return signals


def send_signals():
    signals = check_signal()
    for sig in signals:
        bot.send_message(chat_id=CHAT_ID, text=sig)


if __name__ == "__main__":
    while True:
        send_signals()
        time.sleep(300)
